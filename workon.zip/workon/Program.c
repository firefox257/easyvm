﻿#ifndef PROGRAM_C
#define PROGRAM_C

#pragma pack(1);

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

struct Program
{
	uint8_t * d;
	uint64_t size;
	//uint64_t at=0;
	uint8_t * at;
};

void Program(struct Program * this, uint64_t s)
{
	
	this->size=s;
	this->d=(uint8_t *)malloc(s);
	this->at=this->d;
}

void _Program(struct Program * this)
{
	free(this->d);
	this->size=this->d=this->at=0;
	
}




#endif

﻿#pragma pack(1);

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>


#define STACKSIZE 1048576
//#define STACKSIZE 8388608
#include "Cpu.c"
#include "Program.c"
#include "OpStructs.c"




void Maddsp(struct Program * p,int32_t d)
{
	struct addsp * m = (struct addsp*)(p->at);
	m->op=addsp_;
	m->d=d;
	p->at+=sizeof(struct addsp);
	
}


void Msetri4(struct Program * p, uint8_t r, int32_t d)
{
	struct setri4 * m = (struct setri4*)(p->at);
	m->op=setri4_;
	m->r=r;
	m->d=d;
	p->at+=sizeof(struct setri4);
	
}



void Msetspi4(struct Program * p, uint32_t o, int32_t d)
{
	struct setspi4 * m = (struct setspi4*)(p->at);
	m->op=setspi4_;
	m->o=o;
	m->d=d;
	p->at+=sizeof(struct setspi4);
	
}


void Mprintch1(struct Program * p, char d)
{
	struct printch1 * m = (struct printch1*)(p->at);
	m->op=printch1_;
	m->d=d;
	p->at+=sizeof(struct printch1);
	
}




void Mprintri4(struct Program * p, uint8_t r)
{
	struct printri4 * m = (struct printri4*)(p->at);
	m->op=printri4_;
	m->r=r;
	p->at+=sizeof(struct printri4);
	
}


void Mprintspi4(struct Program * p, int32_t o)
{
	struct printspi4 * m = (struct printspi4*)(p->at);
	m->op=printspi4_;
	m->o=o;
	p->at+=sizeof(struct printspi4);
	
}




void Maddni4spi4(struct Program * p,int32_t o,int32_t d)
{
	struct addni4spi4 * m = (struct addni4spi4*)(p->at);
	m->op=addni4spi4_;
	m->o=o;
	m->d=d;
	p->at+=sizeof(struct addni4spi4);
	
}


void Mmulni4spi4(struct Program * p,int32_t o,int32_t d)
{
	struct mulni4spi4 * m = (struct mulni4spi4*)(p->at);
	m->op=mulni4spi4_;
	m->o=o;
	m->d=d;
	p->at+=sizeof(struct mulni4spi4);
	
}


void Mmodni4spi4(struct Program * p,int32_t o,int32_t d)
{
	struct modni4spi4 * m = (struct modni4spi4*)(p->at);
	m->op=modni4spi4_;
	m->o=o;
	m->d=d;
	p->at+=sizeof(struct modni4spi4);
	
}


void Mlni4spi4pc(struct Program * p,int32_t o,int32_t d, int32_t pco)
{
	struct lni4spi4pc * m = (struct lni4spi4pc*)(p->at);
	m->op=lni4spi4pc_;
	m->o=o;
	m->d=d;
	m->pco=pco;
	p->at+=sizeof(struct lni4spi4pc);
	
}



void Mend(struct Program * p)
{
	struct end * m = (struct end*)(p->at);
	m->op=end_;
	p->at+=sizeof(struct end);
}


#define atsp(I) (*((int32_t *)(c.sp+I)))
void run(struct Cpu c)
{
	
	next:
	
	//void * at = (void *)(c.d+c.pc);
	void * at = (void *)(c.pc);
	switch(*((OpType*)at))
	{
		case addsp_:
		{
			
			struct addsp * m = (struct addsp *)at;
			c.sp+= m->d;
			c.pc+=sizeof(struct addsp);
		}
		goto next;
		case setri4_:
		{
			struct setri4 * m = (struct setri4 *)at;
			c.r[m->r].i4=m->d;
			c.pc+=sizeof(struct setri4);
		}
		goto next;
		case setspi4_:
		{
			struct setspi4 * m = (struct setspi4 *)at;
			*((int32_t *)(c.sp+m->o))=m->d;
			c.pc+=sizeof(struct setspi4);
			
		}
		goto next;
		case printch1_:
		{
			struct printch1* m = (struct printch1 *)at;
			//printf("%d",c.r[m->r].i4);
			putchar(m->d);
			c.pc+=sizeof(struct printch1);
		}
		goto next;
		case printri4_:
		{
			struct printri4 * m = (struct printri4 *)at;
			printf("%d",c.r[m->r].i4);
			c.pc+=sizeof(struct printri4);
		}
		goto next;
		case printspi4_:
		{
			struct printspi4 * m = (struct printspi4 *)at;
			printf("%d",*((int32_t *)(c.sp+m->o)));
			c.pc+=sizeof(struct printspi4);
		}
		goto next;
		case addni4spi4_:
		{
			struct addni4spi4 * m = (struct addni4spi4 *)at;
			(*((int32_t *)(c.sp+m->o)))+=m->d;
			c.pc+=sizeof(struct addni4spi4);
		}
		goto next;
		case mulni4spi4_:
		{
			struct mulni4spi4 * m = (struct mulni4spi4 *)at;
			(*((int32_t *)(c.sp+m->o)))*=m->d;
			c.pc+=sizeof(struct mulni4spi4);
		}
		goto next;
		case modni4spi4_:
		{
			struct modni4spi4 * m = (struct modni4spi4 *)at;
			(*((int32_t *)(c.sp+m->o)))%=m->d;
			c.pc+=sizeof(struct modni4spi4);
		}
		goto next;
		case lni4spi4pc_:
		{
			struct lni4spi4pc * m = (struct lni4spi4pc *)at;
			if(atsp(m->o)<m->d)
			{
				c.pc+=m->pco;
				goto next;
				
			}
			c.pc+=sizeof(struct lni4spi4pc);
		}
		goto next;
		case end_:
		
		
		
	};
	
}



int main()
{
	struct Program p;
	Program(&p, 1000);
	
	
	/*
	Msetri4(&p, 0, 123);
	Mprintri4(&p, 0);
	Mprintch1(&p,'\n');
	Maddsp(&p, 4);
	Msetspi4(&p, -4, 234);
	Mprintspi4(&p,-4);
	Mprintch1(&p,'\n');
	Maddni4spi4(&p, -4, -10);
	
	Mprintspi4(&p,-4);
	Mprintch1(&p,'\n');
	
	Maddsp(&p, -4);
	Mend(&p);
	*/
	
	
	Maddsp(&p, 8);
	Msetspi4(&p, -4, 0);
	Msetspi4(&p, -8, 0);
	int64_t at1=p.at;
	//Mprintspi4(&p,-4);
	//Mprintch1(&p,'\n');
	Mmulni4spi4(&p, -8, 3);
	Maddni4spi4(&p, -8, 1);
	Mmodni4spi4(&p, -8, 123456);
	
	Maddni4spi4(&p, -4, 1);
	Mlni4spi4pc(&p, -4, 1000000, at1-((int64_t)p.at));
	Mprintspi4(&p,-8);
	Maddsp(&p, -8);
	Mend(&p);
	
	
	struct Cpu c;
	
	Cpu(&c, p.d);
	
	run(c);
	
	_Cpu(&c);
	_Program(&p);
	return 0;
}

﻿
#pragma pack(1);
#include <iostream>
#include <stdint.h>
using namespace  std;


struct t
{
	int32_t a;
	int8_t b;
}__attribute((packed));

int main()
{
	cout << sizeof(t) << endl;
	
	
	return 0;
}



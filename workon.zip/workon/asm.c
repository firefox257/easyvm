﻿#pragma pack(1);

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>





int main()
{
	printf("hi there\n");
	
	return 0;
}



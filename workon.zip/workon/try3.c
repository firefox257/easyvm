﻿
#pragma pack(1);

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

void realocstr(char * s, char ** d)
{
	int si=0;
	while(s[si]!=0)si++;
	if((*d)==0)
	{
		(*d)=(char*)malloc(si);
	}
	else
	{
		(*d)=(char*)realloc((*d), si);
	}
		
	si=0;
	while(s[si]!=0)
	{
		(*d)[si]=s[si];
		si++;
	}
	(*d)[si]=0;
}

struct LabelTreeNode
{
	char *  name;
	int64_t ptr;
	struct LabelTreeNode * l;
	struct LabelTreeNode * r; 
	
	
};

void LabelTreeNode(struct LabelTreeNode * self)
{
	self->name=0;
	self->ptr=-1;
	self->l=0;
	self->r=0;
	
	
}
void _LabelTreeNode(struct LabelTreeNode * self)
{
	if(self->l!=0)
	{
		_LabelTreeNode(self->l);
		free(self->l);
		self->l=0;
	}
	if(self->r!=0)
	{
		_LabelTreeNode(self->r);
		free(self->r);
		self->r=0;
	}
	if(self->name !=0)
	{
		free(self->name);
		self->name=0;
	}
	
}
struct LabelTree
{
	struct LabelTreeNode * h;
	
};

void LabelTree(struct LabelTree * self)
{
	self->h=0;
}  
void _LabelTree(struct LabelTree * self)
{
	if(self->h!=0)
	{
		_LabelTreeNode(self->h);
		
	}
}
void LabelTreeAdd(struct LabelTree * self, char * n, int64_t p)
{
	struct LabelTreeNode ** h=&(self->h);
	while((*h)!=0)
	{
		int r =strcmp(n, (*h)->name);
		if(r==0)
		{
			(*h)->ptr=p;
		}
		else if(r<0)
		{
			h=&((*h)->l);
		}
		else 
		{
			h=&((*h)->r);
		}
	}
	(*h)= (struct LabelTreeNode*)malloc(sizeof(struct LabelTreeNode));
	LabelTreeNode((*h));
	//printf("here1\n");
	realocstr(n, &((*h)->name));
	(*h)->ptr=p;
	
}

int64_t  LabelTreeGet(struct LabelTree * self, char * n)
{
	struct LabelTreeNode * h=self->h;
	int r=0;
	do
	{
		r=strcmp(n, h->name);
		if(r<0)h=h->l;
		else if(r>0)h=h->r;
	}
	while(r!=0&&h!=0);
	if(h==0) return -1;
	return h->ptr;
	
}

int main()
{
	struct LabelTree t;
	LabelTree(&t);
	
	LabelTreeAdd(&t, "hi 3", 333);
	LabelTreeAdd(&t, "hi 1", 111);
	LabelTreeAdd(&t, "hi 2", 222);
	int64_t p= LabelTreeGet(&t, "hi 2");
	
	printf("%d\n", p);
	
	
	
	_LabelTree(&t);
	return 0;
}




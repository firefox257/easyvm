﻿#pragma pack(1);
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

 const char tag[]="hi12";

int main()
{
	printf("size: %d\n", sizeof(tag));
	
	
	return 0;
}
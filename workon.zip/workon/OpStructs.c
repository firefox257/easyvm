﻿#ifndef OPSTRUCTS_C
#define OPSTRUCTS_C

#pragma pack(1);
#include <stdint.h>
#define OpType uint16_t

enum OpCode
{
	addsp_, // add to the stacknpointer could be positive or negative 
	setri4_,//set register to const 32bit signed number
	setspi4_,//set 32 byte signed number to stack pointer offset
	printch1_,// print characture 1 byte
	printri4_,
	printspi4_,//print int32 at stack pointer offset
	
	addni4spi4_,// add i32 to sp
	mulni4spi4_,// mul i32 to sp
	modni4spi4_,// mod i32 to sp
	
	lni4spi4pc_,//if sp i32 less than number i32, add offset to pc 
	
	end_
	
};

struct addsp
{
	OpType op;
	int32_t d;
}__attribute((packed));;

struct setri4
{
	OpType op;
	uint8_t r;
	int32_t d;
}__attribute((packed));;

struct setspi4
{
	OpType op;
	int32_t o;
	int32_t d;
}__attribute((packed));;

struct printch1
{
	OpType op;
	char d;
}__attribute((packed));;

struct printri4
{
	OpType op;
	uint8_t r;
}__attribute((packed));;

struct printspi4
{
	OpType op;
	int32_t o;
}__attribute((packed));;

struct addni4spi4
{
	OpType op;
	int32_t o;
	int32_t d;
}__attribute((packed));;

struct mulni4spi4
{
	OpType op;
	int32_t o;
	int32_t d;
}__attribute((packed));;

struct modni4spi4
{
	OpType op;
	int32_t o;
	int32_t d;
}__attribute((packed));;

struct lni4spi4pc
{
	OpType op;
	int32_t o;
	int32_t d;
	int32_t pco;
}__attribute((packed));;

struct end
{
	OpType op;
}__attribute((packed));;


#endif

﻿#pragma pack(1);
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>


struct btreeNode
{
	char * name;
	
};
struct btree
{
	struct btreeNode * head;
	
	
};

void t( int8_t n)
{
	printf("n: %d\r\n", n);
	
}

int main()
{
	
	char * st="hi";
	
	switch(st)
	{
		case "hi":
		printf("at hi\r\n");
		
		
	};
	
	
	float f=12.3;
	t(f);
	FILE * fh;
	fh= fopen("test1.txt", "r");
	
	
	char buff[20000];
	char opc[100];
	int8_t i1;
	fgets(buff, 20000, fh);
	//printf("%s\r\n", buff);
	
	sscanf(buff, "%s %d", opc, &i1);
	printf("%s %d", opc, i1);
	
	
	
	
	
	
	
	return 0;
}

﻿#pragma pack(1);
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

#include "RunProgram.c"



int main()
{
	struct FileProgram p;
	
	FileProgram(&p,"prog1.bin");
	
	struct Cpu c;
	
	
	Cpu(&c, p.d);
	
	
	run(c);
	
	_Cpu(&c);
	_FileProgram(&p);
	printf("done!\n");
	return 0;
}

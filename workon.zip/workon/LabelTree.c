﻿#ifndef LABELTREE_C
#define LABELTREE_C

#pragma pack(1);

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>


void realocstr(char * s, char ** d)
{
	int si=0;
	while(s[si]!=0)si++;
	if((*d)==0)
	{
		(*d)=(char*)malloc(si);
	}
	else
	{
		(*d)=(char*)realloc((*d), si);
	}
		
	si=0;
	while(s[si]!=0)
	{
		(*d)[si]=s[si];
		si++;
	}
	(*d)[si]=0;
}


struct LabelListNode
{
	int64_t ptr;
	int64_t codePtr;
	struct LabelList * next;
	
}; 
void LabelListNode(struct LabelListNode * self)
{
	self->ptr=-1;
	self->codePtr=-1;
	self->next =0;
}

void _LabelListNode(struct LabelListNode * self)
{
	//stub in for now
	
}


struct LabelList
{
	struct LabelListNode * h;
	struct LabelListNode * t;
	
};

void LabelList(struct LabelList * self)
{
	self->h=0;
	self->t=0;
	
}
void _LabelList(struct LabelList * self)
{
	struct LabelListNode * n=self->h;
	while(n!=0)
	{
		struct LabelListNode * n1=n->next;
		_LabelListNode(n);
		free(n);
		n=n1;
	}
	self->h=0;
	self->t=0;
}

void LabelListAdd(struct LabelList * self, int64_t p, int64_t pc)
{
	
	struct LabelListNode * n=(struct LabelListNode *)malloc(sizeof(struct LabelListNode ));
	LabelListNode(n);
	n->ptr=p;
	n->codePtr=pc;
	if(self->h==0)
	{
		self->h=n;
		self->t=n;
	}
	else
	{
		self->t->next=n;
		self->t=self->t->next;
	}
}


struct LabelTreeNode
{
	char *  name;
	int64_t ptr;
	struct LabelTreeNode * l;
	struct LabelTreeNode * r; 
	struct LabelList list;
	
};

void LabelTreeNode(struct LabelTreeNode * self)
{
	self->name=0;
	self->ptr=-1;
	self->l=0;
	self->r=0;
	LabelList(&(self->list));
	
	
}
void _LabelTreeNode(struct LabelTreeNode * self)
{
	_LabelListNode(&(self->list));
	if(self->l!=0)
	{
		_LabelTreeNode(self->l);
		free(self->l);
		self->l=0;
	}
	if(self->r!=0)
	{
		_LabelTreeNode(self->r);
		free(self->r);
		self->r=0;
	}
	if(self->name !=0)
	{
		free(self->name);
		self->name=0;
	}
	
}
struct LabelTree
{
	struct LabelTreeNode * h;
	
};

void LabelTree(struct LabelTree * self)
{
	self->h=0;
}  
void _LabelTree(struct LabelTree * self)
{
	if(self->h!=0)
	{
		_LabelTreeNode(self->h);
		
	}
}

struct LabelTreeNode  ** LabelTreeGetLabelPtr(struct LabelTree * self, char * n)
{
	struct LabelTreeNode **h=&(self->h);
	
	int r=1;
	
	
	while((*h)!=0 && r!=0)
	{
		r =strcmp(n, (*h)->name);
		if(r==0)
		{
			return h;
		}
		else if(r<0)
		{
			h=&((*h)->l);
		}
		else 
		{
			h=&((*h)->r);
		}
	}
	
	//printf("here1: %d\n", 
	if((*h)==0)
	{
		(*h)= (struct LabelTreeNode*)malloc(sizeof(struct LabelTreeNode));
		LabelTreeNode((*h));
		//printf("here1\n");
		realocstr(n, &((*h)->name));
		//(*h)->ptr=p;
	}
	return h;
}


void LabelTreeSetLabel(struct LabelTree * self, char * n, int64_t p)
{
	struct LabelTreeNode **h=LabelTreeGetLabelPtr(self, n);
	(*h)->ptr=p;
	// set the ptrs in the list
	struct LabelListNode * ll=(*h)->list.h;
	if(ll!=0)
	{
		while(ll!=0)
		{
			///here123
			*((int64_t *)(ll->ptr))=p-ll->codePtr;
			ll=ll->next;
			
		}//*/
		_LabelList( &((*h)->list));
	
	}
}



int64_t  LabelTreeGet(struct LabelTree * self, char * n)
{
	struct LabelTreeNode ** h=LabelTreeGetLabelPtr(self, n);
	return (*h)->ptr;
	
}


void LabelTreeAddGoto(struct LabelTree * self, char * n, int64_t ptr, int64_t codePtr)
{
	struct LabelTreeNode **h=LabelTreeGetLabelPtr(self, n);
	if((*h)->ptr>=0)
	{
		*((int64_t *)(ptr))=((*h)->ptr)-codePtr;
	}
	else
	{
		LabelListAdd(&((*h)->list), ptr, codePtr);
	}	
	
	
}

int main()
{
	struct LabelTree t;
	LabelTree(&t);
	
	
	int64_t a[1000];
	for(int i=0; i<1000;i++)
	{
		a[i]=0;
	}
	
	int64_t aaa=&a[0];
	//LabelTreeAddGoto(&t, "for1", aaa, 20);
	
	
	LabelTreeSetLabel(&t, "for1", 10);
	
	LabelTreeAddGoto(&t, "for1", aaa, 20);
	printf("h: %d\n", a[0]);
	
	/*LabelTreeSetLabel(&t, "hi 3", 333);
	LabelTreeSetLabel(&t, "hi 1", 111);
	LabelTreeSetLabel(&t, "hi 2", 222);
	int64_t p= LabelTreeGet(&t, "hi 25555");
	*/
	
	
	//printf("%d\n", p);
	
	
	
	/*struct LabelList ll;
	LabelList(&ll);
	
	LabelListAdd(&ll, 11, 112);
	LabelListAdd(&ll, 2, 222);
	LabelListAdd(&ll, 333, 332);
	LabelListAdd(&ll, 1, 12);
	LabelListAdd(&ll, 9999, 99992);
	LabelListAdd(&ll, 888888, 88888882);
	
	
	struct LabelListNode * nn=ll.h;
	
	while(nn!=0)
	{
		printf("::%d\n", nn->ptr);
		nn=nn->next;
		
	}
	
	
	_LabelList(&ll);//*/
	_LabelTree(&t);
	return 0;
}

#endif


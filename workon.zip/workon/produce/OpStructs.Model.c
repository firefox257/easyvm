﻿#ifndef OPSTRUCTS_C
#define OPSTRUCTS_C

#pragma pack(1);
#include <stdint.h>
#define OpType uint16_t

#ifndef TAG
#define TAG "EVM"
#endif


const char filetag[]=TAG;

enum OpCode
{
	#enum
	end_
	
};


#structs

#endif

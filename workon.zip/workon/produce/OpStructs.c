﻿#ifndef OPSTRUCTS_C
#define OPSTRUCTS_C

#pragma pack(1);
#include <stdint.h>
#define OpType uint16_t

#ifndef TAG
#define TAG "EVM"
#endif


const char filetag[]=TAG;

enum OpCode
{
	addsp_,
	setri4_,
	setspi4_,
	printch1_,
	printri4_,
	printspi4_,
	addni4spi4_,
	mulni4spi4_,
	modni4spi4_,
	lni4spi4pc_,
	end_
	
};


struct addsp
{
	OpType op;
	int32_t d;
}__attribute((packed));
struct setri4
{
	OpType op;
	uint8_t r;
	int32_t d;
}__attribute((packed));
struct setspi4
{
	OpType op;
	int32_t o;
	int32_t d;
}__attribute((packed));
struct printch1
{
	OpType op;
	char d;
}__attribute((packed));
struct printri4
{
	OpType op;
	uint8_t r;
}__attribute((packed));
struct printspi4
{
	OpType op;
	int32_t o;
}__attribute((packed));
struct addni4spi4
{
	OpType op;
	int32_t o;
	int32_t d;
}__attribute((packed));
struct mulni4spi4
{
	OpType op;
	int32_t o;
	int32_t d;
}__attribute((packed));
struct modni4spi4
{
	OpType op;
	int32_t o;
	int32_t d;
}__attribute((packed));
struct lni4spi4pc
{
	OpType op;
	int32_t o;
	int32_t d;
	int32_t pco;
}__attribute((packed));

#endif


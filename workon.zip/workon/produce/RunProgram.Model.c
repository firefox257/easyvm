﻿#pragma pack(1);
#ifndef RUNPROGRAM_C
#define RUNPROGRAM_C

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

#include "OpStructs.c"
#include "Cpu.c"

struct FileProgram
{
	uint8_t * d;
	uint64_t size;
};

void FileProgram(struct FileProgram * self, char * name)
{
	FILE * fb = fopen(name, "rb");
	char tag[sizeof(filetag)];
	fread(tag, 1,sizeof(filetag),fb);
	
	fread(&(self->size), 1, sizeof(uint64_t), fb);
	//printf("size: %d\n", self->size);
	
	self->d=(uint8_t *) malloc((uint32_t  )(self->size));
	
	/*
	uint8_t b;
	for( uint64_t i=0; i< self->size; i++)
	{
		fread(&b, 1,1,fb);
		self->d[i]=b;
	}
	*/
	
	fread(self->d, 1, self->size, fb);
	
	
}

void _FileProgram(struct FileProgram * self)
{
	
	free(self->d);
	self->size=0;
	self->d=0;
}

#define atsp(I) (*((int32_t *)(c.sp+I)))
void run(struct Cpu c)
{
	
	next:
	
	//void * at = (void *)(c.d+c.pc);
	
	void * at = (void *)(c.pc);
	
	
	switch(*((OpType*)at))
	{
		#switchcode
		case end_:
		break;
		
		default:
		printf("not found op code %d\n", *((OpType*)at));
		
		
		
	};
	
}




#endif

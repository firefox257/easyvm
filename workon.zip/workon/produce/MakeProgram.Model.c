﻿#pragma pack(1);

#ifndef MAKEPROGRAM_C
#define MAKEPROGRAM_C
#define BUFSIZ 10


#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

#include "OpStructs.c"

struct Program
{
	uint8_t * d;
	uint64_t size;
	//uint64_t at=0;
	uint8_t * at;
};

void Program(struct Program * self, uint64_t s)
{
	
	self->size=s;
	self->d=(uint8_t *)malloc(s);
	self->at=self->d;
}

void _Program(struct Program * self)
{
	free(self->d);
	self->size=0;
	self->d=self->at=0;
	
}

void ProgramWriteFile(struct Program * self, char * name)
{
	
	FILE * fb =fopen(name, "w");
	uint8_t bufff[1000];
	setbuf(fb, bufff);
	fwrite(filetag,1, sizeof(filetag),fb);
	
	uint64_t size =((uint64_t )self->at-(uint64_t )self->d);
	
	printf("sizeis:%d\n", size);
	fwrite(&size,8, 1,fb);
	fwrite((self->d), 1, size, fb);
	//char cc='#';
	//fwrite(&cc,1,1,fb);
	fflush(fb);
	
	fclose(fb);
	
}


#makecode


#endif

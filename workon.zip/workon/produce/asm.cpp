﻿


#include <stdint.h>
#include <iostream>
#include <fstream>
#include <list>
#include <string>

using namespace std;

class opitems
{
	
	
	
};


int main()
{
	printf("hi there\n");
	
	return 0;
}


